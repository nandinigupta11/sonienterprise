var currentSlide = 0;
var slides = document.querySelectorAll('.slide');
var dots = document.querySelectorAll('.dot');

function changeSlide(n) {
  currentSlide = n;
  slides.forEach(function(slide, i) {
    slide.style.transform = 'translateX(' + (i - currentSlide) * 100 + '%)';
  });
  dots.forEach(function(dot, i) {
    dot.classList.remove('active');
    if (i === currentSlide) {
      dot.classList.add('active');
    }
  });
}

// Auto transition
setInterval(function() {
  currentSlide = (currentSlide + 1) % slides.length;
  changeSlide(currentSlide);
}, 3000);